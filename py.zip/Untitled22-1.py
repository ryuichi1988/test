aList = [123, 'xyz', 'runoob', 'abc']
for line in aList:
    print((aList.index( line )))
    print(type(aList.index( line )))